import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class MiDBUno {
    private int numLects = 0;
    private int escribiendo = 0;

    private final Lock lock = new ReentrantLock();
    private final Condition elvc = lock.newCondition();

    public MiDBUno() {
    }

    public void puedeLeer() throws InterruptedException {
	lock.lock();
	try {
		while(escribiendo != 0){
			elvc.await();
 		}
		numLects++;
	} finally {
		lock.unlock();
	}
    }

    public void liberaLeer() throws InterruptedException {
	lock.lock();
	try {
		numLects--;
		if(numLects == 0){
			elvc.signalAll();
 		}
	} finally {
		lock.unlock();
	}
    }

    public void puedeEscribir() throws InterruptedException {
	  lock.lock();
	  try {
		while(escribiendo != 0 || numLects > 0){
			elvc.await();
	  	}	
		escribiendo = 1;
	  } finally {
		lock.unlock();
	  }
    }

    public void liberaEscribir() throws InterruptedException {
	  lock.lock();
	  try {
		escribiendo = 0;
		elvc.signalAll();
	  } finally {
		lock.unlock();
	  }
    }

}
