import java.util.*;


public class TestMonLEUno {
  public static void main(String[] args){
    MiDBUno db = new MiDBUno();
    EscritorUno w1 = new EscritorUno(db, new Integer(1));
    EscritorUno w2 = new EscritorUno(db, new Integer(1));
    LectorUno r1 = new LectorUno(db, new Integer(1));
    LectorUno r2 = new LectorUno(db, new Integer(1));
    LectorUno r3 = new LectorUno(db, new Integer(1));
    
    w1.start();
    r1.start();
    w2.start();
    r2.start();
    r3.start();

  }
}
  
