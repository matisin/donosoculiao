public class LectorSync extends Thread {
    private MiDBSync db;
    private int id;

    public LectorSync(MiDBSync db, Integer id) {
        this.db = db;
	this.id = id.intValue();
	this.setName(new String(id.toString()));
    }

    public void run() {
        for (int i = 1; i <= 10; i++) {
            try {
                db.puedeLeer();
		Thread.sleep((long)(Math.random() * 1000));
                System.out.println("\tLector reading " + i);
                db.liberaLeer();
            } catch (InterruptedException e) {
                System.out.println("Error al consumir : " + e.getMessage());
            }
        }
    }

}
