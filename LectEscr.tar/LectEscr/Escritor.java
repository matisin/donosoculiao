import java.lang.*;

public class Escritor extends Thread {
    private MiDB db;
    private int id;
    private static int number=0;

    public Escritor(MiDB db, Integer id) {
        this.db = db;
	this.id = id.intValue();
	this.setName(new String(id.toString()));
    }

    public void run() {
        for (int i = 1; i <= 50; i++) {
            try {
		Thread.sleep((long)(Math.random() * 2000));
                db.puedeEscribir();
                System.out.println("Escritor item : " + i);
                db.liberaEscribir();
            } catch (InterruptedException e) {
                System.out.println("Error al producir : " + e.getMessage());
            }
        }
    }

}
