import java.lang.*;

public class EscritorSync extends Thread {
    private MiDBSync db;
    private int id;
    private static int number=0;

    public EscritorSync(MiDBSync db, Integer id) {
        this.db = db;
	this.id = id.intValue();
	this.setName(new String(id.toString()));
    }

    public void run() {
        for (int i = 1; i <= 10; i++) {
            try {
                db.puedeEscribir();
		Thread.sleep((long)(Math.random() * 1000));
                System.out.println("Escritor item : " + i);
                db.liberaEscribir();
            } catch (InterruptedException e) {
                System.out.println("Error al producir : " + e.getMessage());
            }
        }
    }

}
