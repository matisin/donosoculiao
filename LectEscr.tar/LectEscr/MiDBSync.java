import java.util.*;
import java.util.concurrent.*;

public class MiDBSync {
    private int numLects = 0;
    private int escribiendo = 0;


    public MiDBSync() {
    }

    public synchronized void puedeLeer() throws InterruptedException {
		while(escribiendo != 0){
			wait();
 		}
		numLects++;
    }

    public synchronized void liberaLeer() throws InterruptedException {
		numLects--;
		if(numLects == 0){
			notifyAll();
 		}
    }

    public synchronized void puedeEscribir() throws InterruptedException {
		while(escribiendo != 0 || numLects > 0){
			wait();
	  	}	
		escribiendo = 1;
    }

    public synchronized void liberaEscribir() throws InterruptedException {
		escribiendo = 0;
		notifyAll();
    }

}
