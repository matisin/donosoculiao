import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class MiDB {
    private int numLects = 0;
    private int escribiendo = 0;
    private int lectesperando = 0;
    private int escresperando = 0;

    private final Lock lock = new ReentrantLock();
    private final Condition leervc = lock.newCondition();
    private final Condition escribirvc = lock.newCondition();

    public MiDB() {
    }

    public void puedeLeer() throws InterruptedException {
	lock.lock();
	try {
		lectesperando++;
		while(escribiendo != 0 || escresperando > 0){
			leervc.await();
 		}
		lectesperando--;
		numLects++;
	} finally {
		lock.unlock();
	}
    }

    public void liberaLeer() throws InterruptedException {
	lock.lock();
	try {
		numLects--;
		if(numLects == 0 && escresperando > 0 ){
			escribirvc.signal();
 		}
	} finally {
		lock.unlock();
	}
    }

    public void puedeEscribir() throws InterruptedException {
	  lock.lock();
	  try {
		escresperando++;
		while(escribiendo != 0 || numLects > 0){
			escribirvc.await();
	  	}	
		escresperando--;
		escribiendo = 1;
	  } finally {
		lock.unlock();
	  }
    }

    public void liberaEscribir() throws InterruptedException {
	  lock.lock();
	  try {
		escribiendo = 0;
	  	if(escresperando > 0 ){
			escribirvc.signal();
	  	} else {
			leervc.signalAll();
		}
	  } finally {
		lock.unlock();
	  }
    }

}
