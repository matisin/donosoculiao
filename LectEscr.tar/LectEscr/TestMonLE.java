import java.util.*;


public class TestMonLE {
  public static void main(String[] args){
    MiDB db = new MiDB();
    Escritor w1 = new Escritor(db, new Integer(1));
    Lector r1 = new Lector(db, new Integer(1));
    Lector r2 = new Lector(db, new Integer(1));
    Lector r3 = new Lector(db, new Integer(1));
    
    r1.start();
    w1.start();
    r2.start();
    r3.start();

  }
}
  
