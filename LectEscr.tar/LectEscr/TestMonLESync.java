import java.util.*;


public class TestMonLESync {
  public static void main(String[] args){
    MiDBSync db = new MiDBSync();
    EscritorSync w1 = new EscritorSync(db, new Integer(1));
    EscritorSync w2 = new EscritorSync(db, new Integer(2));
    LectorSync r1 = new LectorSync(db, new Integer(3));
    LectorSync r2 = new LectorSync(db, new Integer(4));
    LectorSync r3 = new LectorSync(db, new Integer(5));
    
    w1.start();
    r1.start();
    w2.start();
    r2.start();
    r3.start();

  }
}
  
